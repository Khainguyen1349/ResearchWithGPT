from lwa_modeling import geometry

def test_lwa_point_count():
    xk, yk, uk = geometry.define_concave_lwa(0.67, 0.3, 100)
    assert len(xk) == 100
