import numpy as np

def define_concave_lwa(radius, arc_length, num_points):
    theta_arc = arc_length / radius
    theta = np.linspace(-theta_arc / 2, theta_arc / 2, num_points)
    xk = radius * np.sin(theta)
    yk = -radius * (1 - np.cos(theta))
    uk = np.array([np.cos(theta), -np.sin(theta)])
    return xk, yk, uk
