import numpy as np

def compute_field_on_observation_arc(angles_rad, χk, sk, nk, xi_k, sigma_k, A_aperture, Tk, delta_L_prime, beta, kd, k0, R_obs):
    obs_points = R_obs * np.array([np.sin(angles_rad), np.cos(angles_rad)])
    E_theta = np.zeros(len(angles_rad), dtype=complex)
    for k in range(len(xk)):
        chi = χk[:, k]
        r_vec = obs_points - chi[:, np.newaxis]
        r_norm = np.linalg.norm(r_vec, axis=0)
        r_hat = r_vec / r_norm
        phase = beta * xi_k[k] + kd * sigma_k[k] + k0 * r_norm
        proj = np.dot(nk[:, k], sk[:, k]) + np.sum(nk[:, k, np.newaxis] * r_hat, axis=0)
        E_theta += A_aperture[k] * np.exp(-1j * phase) * proj * Tk[k] * delta_L_prime[k]
    E_theta /= np.max(np.abs(E_theta))
    return 20 * np.log10(np.abs(E_theta) + 1e-12)
