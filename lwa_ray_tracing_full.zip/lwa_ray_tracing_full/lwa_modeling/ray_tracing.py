import numpy as np

def generate_ray_directions(theta_LWA, beta, kd):
    theta_k = np.arcsin(beta / kd)
    ϕd_k = theta_LWA + theta_k
    σk = np.array([np.sin(ϕd_k), np.cos(ϕd_k)])
    return σk, ϕd_k

def intersect_rays_with_lens(xk, yk, σk, lens_radius):
    χk = []
    for i in range(len(xk)):
        dx, dy = σk[0, i], σk[1, i]
        x0, y0 = xk[i], yk[i]
        a = dx**2 + dy**2
        b = 2 * (x0 * dx + y0 * dy)
        c = x0**2 + y0**2 - lens_radius**2
        t = (-b + np.sqrt(b**2 - 4*a*c)) / (2*a)
        χk.append([x0 + t * dx, y0 + t * dy])
    χk = np.array(χk).T
    nk = χk / np.linalg.norm(χk, axis=0)
    return χk, nk

def compute_exit_directions(σk, nk, εr):
    cos_phi_i_k = np.sum(σk * nk, axis=0)
    sin_phi_i_k = σk[0, :] * nk[1, :] - σk[1, :] * nk[0, :]
    sin_phi_r_k = np.sqrt(εr) * sin_phi_i_k
    phi_r_k = np.arcsin(np.clip(sin_phi_r_k, -1.0, 1.0))
    phi_n_k = np.arctan2(nk[0, :], nk[1, :])
    phi_0_k = phi_n_k + phi_r_k
    sk = np.array([np.sin(phi_0_k), np.cos(phi_0_k)])
    return sk, phi_0_k
