import numpy as np

def compute_aperture_amplitude(xk, yk, χk, σk, sk, nk, xi_k, alpha, beta, εr):
    A0 = 1.0
    A_LWA = A0 * np.sqrt(alpha) * np.exp(-alpha * xi_k)
    delta_L = np.linalg.norm(np.gradient(np.vstack((xk, yk)), axis=1), axis=0)
    delta_L_prime = np.linalg.norm(np.gradient(χk, axis=1), axis=0)
    dot_sigma_uk = np.sum(σk * np.vstack((np.gradient(xk), np.gradient(yk))), axis=0)
    dot_sk_nk = np.sum(sk * nk, axis=0)
    cos_phi_i_k = np.sum(σk * nk, axis=0)
    phi_r_k = np.arcsin(np.clip(np.sqrt(εr) * (σk[0, :] * nk[1, :] - σk[1, :] * nk[0, :]), -1.0, 1.0))
    Tk = 2 * cos_phi_i_k / (cos_phi_i_k + np.sqrt(1 / εr) * np.cos(phi_r_k))
    sigma_k = np.linalg.norm(χk - np.vstack((xk, yk)), axis=0)
    A_aperture = A_LWA * np.sqrt((delta_L * dot_sigma_uk) / (delta_L_prime * dot_sk_nk)) * Tk
    return A_aperture, Tk, delta_L_prime, sigma_k
