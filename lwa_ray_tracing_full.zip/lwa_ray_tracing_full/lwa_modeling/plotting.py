import matplotlib.pyplot as plt

def plot_field(angles_deg, E_dB):
    plt.figure(figsize=(10, 5))
    plt.plot(angles_deg, E_dB)
    plt.xlabel('Angle [deg]')
    plt.ylabel('Normalized |E(θ)| [dB]')
    plt.grid(True)
    plt.title('Radiation Pattern on Observation Arc')
    plt.ylim(-40, 0)
    plt.show()
