# Example script for single frequency simulation
