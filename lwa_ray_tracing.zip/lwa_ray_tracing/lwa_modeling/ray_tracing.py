# Ray tracing functions go here
