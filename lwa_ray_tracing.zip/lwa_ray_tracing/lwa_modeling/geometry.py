# Geometry functions go here
