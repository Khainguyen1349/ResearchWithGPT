import numpy as np

c = 3e8
f = 15e9
λ0 = c / f
εr = 2.2
k0 = 2 * np.pi / λ0
kd = k0 * np.sqrt(εr)
beta = 0.53 * k0
alpha = 0.0089 * k0
