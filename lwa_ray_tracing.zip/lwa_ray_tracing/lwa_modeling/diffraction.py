# Diffraction field calculations go here
