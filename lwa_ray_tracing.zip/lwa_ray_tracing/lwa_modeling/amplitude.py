# Amplitude calculations go here
